var movimientos = 0;
var grupoTarjetas = [["🦄", "🍦"], ["🌈", "👽"], ["👾", "🤖"]];
var nivelActual = 0;
// EJERCICIO: Crea una variable niveles y asígnale un array que
// contenga los niveles del juego, agrupados en objetos {} separados
// por comas.

// EJERCICIO: Para cada objeto (o "nivel"), asigna las propiedades
// de tarjetas y movimientosMax

// EJERCICIO: asigna uno o varios valores del array de grupoTarjetas
// a las tarjetas de cada nivel.

// BONUS: Modifica y amplia los niveles. Puedes convertir los
// movimientos "sobrantes" de cada nivel en la puntuación final
// del jugador.
