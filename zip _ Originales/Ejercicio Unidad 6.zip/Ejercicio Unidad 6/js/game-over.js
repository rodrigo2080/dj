function gameOver() {
  document.querySelector("#gameOver").classList.add("visible");
}
