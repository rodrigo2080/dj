var grupoTarjetas = ["🦄", "🍦", "🌈", "👽", "👾", "🤖", "👹"];
var totalTarjetas = grupoTarjetas.concat(grupoTarjetas);
